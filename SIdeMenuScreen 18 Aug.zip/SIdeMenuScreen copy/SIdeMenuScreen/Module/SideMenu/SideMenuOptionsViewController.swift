//
//  SideMenuOptionsViewController.swift
//  SIdeMenuScreen

import UIKit
import SideMenuSwift

class SideMenuOptionsViewController: UIViewController {

    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var tblView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        dropShadow()
        // Do any additional setup after loading the view.
    }
    
    
    func dropShadow() {
        contentView.layer.masksToBounds = false
        contentView.layer.shadowOffset = CGSize(width: 2, height: 0)
        contentView.layer.shadowColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1).cgColor
        contentView.layer.shadowOpacity = 0.29
        contentView.layer.shadowPath = nil
    }
    
    @IBAction func closeMenuBar(_ sender: UIButton) {
        self.sideMenuController?.hideMenu()
    }
}
