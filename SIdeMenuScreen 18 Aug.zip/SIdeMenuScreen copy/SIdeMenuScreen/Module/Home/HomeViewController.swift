//
//  HomeViewController.swift
//  SIdeMenuScreen
  
import UIKit
import SideMenuSwift

class HomeViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func showSidemenuPressed(sender: UIButton) {
        sideMenuController?.revealMenu()
    }
}
